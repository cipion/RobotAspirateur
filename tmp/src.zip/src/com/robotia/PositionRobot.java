package com.robotia;


public class PositionRobot {

    private PositionRobot()
    {

    }

    private static PositionRobot INSTANCE  = new PositionRobot();
    private int                  PositionX = 0;
    private int                  PositionY = 0;
    private int                  Angle     = 0;

    public static PositionRobot getInstancePosition()
    {
        return INSTANCE;
    }

    public int getAngle() {
        return Angle;
    }

    public int getPositionX() {
        return PositionX;
    }

    public int getPositionY() {
        return PositionY;
    }

}
