package com.robotia;

import java.util.ResourceBundle;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GestionMouvement {

    private ClientSocket        socket              = null;
    private static final Logger logger              = LoggerFactory.getLogger( GestionMouvement.class );
    private int                 nbPas               = 0;
    private ResourceBundle      bundle;
    private PositionRobot       position;
    private int                 timeoutRotation;
    private Boolean             continuerTraitement = true;

    public GestionMouvement() {
        logger.info( "Initialisation du gestionnaire des mouvements" );
        socket = Main.getSocket();

        logger.info( "Initialisation des varialbes des sockets" );

        bundle = ResourceBundle.getBundle( "config" );

        position = PositionRobot.getInstancePosition();
        timeoutRotation = Integer.parseInt( bundle.getString( "gestionMouvement.timeoutRotation" ) );
    }

    public Boolean StopGestionMouvement()
    {
        if ( socket.stopSocket() )
        {
            logger.info( "Arret de la commande des mouvements" );
            return true;
        }
        else
        {
            logger.error( "Erreur lors de l'arret de la commande des mouvements" );
            return false;
        }
    }

    /***
     * Fonction de rotation sur place de 90°, -90° ou 180°
     * 
     * @param degres
     * @return
     */
    private Boolean rotationRobot( int degres )
    {
        if ( degres == 90 || degres == -90 )
        {
            nbPas = Integer.parseInt( bundle.getString( "socket.driverMoteur.nbPas90" ) );

            logger.debug( "degres est de " + degres + ", le nombre de pas est de " + nbPas );
            return socket.setDriverMoteurStatut( Commandes.ROTATE, 5, degres, nbPas );
        }
        else if ( degres == 180 || degres == -180 )
        {
            nbPas = Integer.parseInt( bundle.getString( "socket.driverMoteur.nbPas180" ) );

            logger.debug( " degres est de " + degres + ", le nombre de pas est de " + nbPas );
            return socket.setDriverMoteurStatut( Commandes.ROTATE, 5, degres, nbPas );
        }
        else
        {
            logger.error( "Erreur, l'angle doit etre de 90, -90 ou 180" );
            return false;
        }

    }

    /****
     * Fonction qui fait avancer les robot en fonction du nobmre de pas demandés
     * S'il n'y a pas de valeur de pas indiqué, le robot avance idefiniement
     * 
     * @param nbPas
     *            (0 pour infini)
     * @return
     */
    private Boolean marcheAvantRobot()
    {

        return socket.setDriverMoteurStatut( Commandes.START, 100, 0 );
    }

    private Boolean marcheAvantRobot( int nbPas )
    {

        return socket.setDriverMoteurStatut( Commandes.START, 100, 0, nbPas );

    }

    private Boolean arretRobot()
    {
        try {
            TimeUnit.SECONDS.sleep( 1 );
        } catch ( InterruptedException e ) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return socket.setDriverMoteurStatut( Commandes.STOP, 0, 0 );

    }

    private Boolean detectionObstacle()
    {
        logger.info( "lancement des detections des capteurs : " );
        String msg = socket.getDetectionObstacle();

        if ( msg.equals( "-1" ) )
        {
            logger.error( "Erreur, le driver de capteur à rencontré un probleme" );
            return false;
        }
        else
        {
            return true;
        }

    }

    public int detectionObstacle( int timeout )
    {
        FutureTask<String> timeoutTask = null;
        String msg = "-3";

        try {
            timeoutTask = new FutureTask<String>( new Callable<String>() {

                @Override
                public String call() throws Exception {
                    logger.debug( "lancement des detections des capteurs avec timeout: " );
                    String msg = socket.getDetectionObstacle( timeout );

                    return msg;
                }
            } );

            new Thread( timeoutTask ).start();
            msg = timeoutTask.get( timeout, TimeUnit.SECONDS );

        } catch ( InterruptedException e ) {

        } catch ( ExecutionException e ) {
            logger.error( "Erreur d'execussion de la detection d'obstacle : " + e.toString() );
            return -1;

        } catch ( TimeoutException e ) {
            logger.debug( "Timeout dépassé, pas d'obstacle detecté :" + e.toString() );
            return -2;
        }

        socket.stopDetection();
        if ( msg.equals( "-1" ) )
        {
            logger.error( "Erreur, le driver de capteur à rencontré un probleme" );
            return -1;
        }
        else if ( msg.equals( "-2" ) )
        {
            logger.error( "Erreur d'execution de connexion au driver" );
            return -1;
        }
        else if ( msg.equals( "-3" ) )
        {
            logger.error( "Erreur d'execution du tread de timeout" );
            return -1;
        }
        else
        {
            logger.debug( "Obstacle detecté : " + msg );
            return 0;
        }

    }

    public Boolean nettoyage()
    {

        logger.debug( "Debut du nettoyage, marche avant" );
        int i = 0;

        while ( i < 6 )
        {
            marcheAvantRobot();

            detectionObstacle( 2 );

            i++;
        }

        return true;

    }
}
