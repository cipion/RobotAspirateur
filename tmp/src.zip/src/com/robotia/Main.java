package com.robotia;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Main {

    private static final Logger logger = LoggerFactory.getLogger( Main.class );
    private static ClientSocket socket = null;

    public static void main( String[] args ) {
        logger.info( "Démarrage du programme RobotAspirateur IA" );
        socket = new ClientSocket();
        GestionMouvement gestionM = new GestionMouvement();

        if ( !socket.initSocket() )
        {
            logger.error( "Erreur d'initialisation du socket" );
            socket.stopSocket();
        }

        logger.info( "Passage d'une commande" );

        gestionM.nettoyage();

        logger.info( "Arret du programme" );

        gestionM.StopGestionMouvement();
    }

    /*****
     * Fonction de partage du singleton du socket client
     * 
     * @return
     */
    public static ClientSocket getSocket()
    {
        return socket;

    }

}
